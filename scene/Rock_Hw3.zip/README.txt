3D Scene
Peter Rock
CSCI 4229


left / right arrow keys to rotate view around the y axis

up / down arrow keys to rotate the view and the x axis

page_up / page_down to zoom in and out of the scene

f / r to decrease or increase number of rings on bracelet by 1

a / d to decrease or increase bracelet center x value by 0.1

s / w to decrease or increase bracelet center y value by 0.1

q / e to decrease or increase bracelet center z value by 0.1

0 reset view parameters

1 toggle axes

esc to exit window



Time to complete assignment: 10 hours (I messed up my parametrization of the torus)

Code Resources:
  A lot of the code for this assignment was taken or modified from the code for ex9
  shown in class on Thursday, 20 September 2018. This is noted in the descriptions
  given before functions.
