Final Project
Peter Rock
CSCI 4229


Key bindings
  l          Toggles lighting
  arrows     Move body
  a/s/d/w    Change head position
  r/f        Move up and down vertically
  m          Toggles light movement
  []         Lower/rise light
  +/-        Change field of view of perspective
  >/<        Move light
  0          Reset view angle
  ESC        Exit




Time to Complete: ~81 Hours.

Project Notes:
  The trees are the most noteworthy things in here, and I am super happy with
  how they turned out. I also managed to get the render time down to something
  reasonable and it runs halfway decently on my laptop, so this should run without
  a problem. It's also fun to sit there and turn the fog on and off.
