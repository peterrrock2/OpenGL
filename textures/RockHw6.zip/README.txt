Textures
Peter Rock
CSCI 4229


Key bindings
  l          Toggles lighting
  a/A        Decrease/increase ambient light
  d/D        Decrease/increase diffuse light
  s/S        Decrease/increase specular light
  e/E        Decrease/increase emitted light
  r/F        Decrease/increase number of rings
  m          Toggles light movement
  []         Lower/rise light
  p          Toggles ortogonal/perspective projection
  +/-        Change field of view of perspective
  x          Toggle axes
  arrows     Change view angle
  PgDn/PgUp  Zoom in and out
  0          Reset view angle
  ESC        Exit




Time to complete assignment: 7 Hours.

Code Resources:
  A lot of the code for this assignment was taken or modified from the code from the previous
  assignment. Any other references used are noted in the descriptions before the functions.
