Lorenz Attractor
Peter Rock
CSCI 4229


left / right arrow keys to rotate view around the x axis

up / down arrow keys to rotate the view and the y axis

page_up / page_down to zoom in and out of the attractor

s / x to decrease or increase sigma value by 1

d / c to decrease or increase beta value by 0.3333

f / v to decrease or increase rho value by 1

r / t reset the animation or terminate the animation

0 reset window to starting parameters

esc to exit window



Time to complete assignment: 12 hours (I messed around a lot)
